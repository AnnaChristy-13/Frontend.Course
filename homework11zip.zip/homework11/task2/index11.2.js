// Задача2:
// На странице есть div с текстом и кнопка ok , сделать так , чтобы кнопка красила текст в красный цвет при нажатии.

const textToRed=()=>{
const textElement = document.querySelector('.textColorChange h2');
textElement.style.color="red";
}
