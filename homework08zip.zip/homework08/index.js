let a = 12;
let b = "стульев"
let c = true;

console.log(a+b+c);
a = 'номер'
b = 2

console.log(a+b);